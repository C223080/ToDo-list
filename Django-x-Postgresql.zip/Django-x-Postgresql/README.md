# DBMS_DJANGO_BACKEND
## Technologies used :
### Django -> djangorestframework -> psycopg2
### Postgresql -> pgadmin4
### Postman
